import React, { useEffect, useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import * as speechCommands from '@tensorflow-models/speech-commands';

const App = () => {
  const URL = 'https://teachablemachine.withgoogle.com/models/iF4oN3hXh/';
  const [recognizer, setRecognizer] = useState(null);
  const [classLabels, setClassLabels] = useState([]);
  const [results, setResults] = useState([]);

  const findMax = (arr) => {
    let max = arr[0].score;
    let maxIndex = 0;

    for (let i = 1; i < arr.length; i++) {
      if (arr[i].score > max) {
        maxIndex = i;
        max = arr[i];
      }
    }

    return maxIndex;
  };

  useEffect(() => {
    const createModel = async () => {
      const checkpointURL = URL + 'model.json';
      const metadataURL = URL + 'metadata.json';

      const recognizer = speechCommands.create(
        'BROWSER_FFT',
        undefined,
        checkpointURL,
        metadataURL
      );

      await recognizer.ensureModelLoaded();
      setRecognizer(recognizer);
      setClassLabels(recognizer.wordLabels());
    };

    createModel();
  }, []);

  const handleStart = () => {
    if (recognizer) {
      recognizer.listen(
        (result) => {
          const scores = result.scores;
          const humans = [];

          for (let i = 0; i < classLabels.length; i++) {
            const classPrediction = classLabels[i] + ': ' + result.scores[i].toFixed(2);
            const human = {
              class: classLabels[i],
              score: result.scores[i].toFixed(2),
            };
            humans.push(human);
          }
          setResults(humans);

          const threshold = 0.75;
          setTimeout(() => recognizer.stopListening(), 5000);

          if (scores[scores.length - 1] > threshold) {
            console.log('Kh nhan dien duoc!!!');
          } else {
            const finded = findMax(scores);
            console.log('Ket qua: ', classLabels[finded]);
          }
        },
        {
          includeSpectrogram: true,
          probabilityThreshold: 0.75,
          invokeCallbackOnNoiseAndUnknown: true,
          overlapFactor: 0.5,
        }
      );
    }
  };

  const handleStop = () => {
    if (recognizer) {
      recognizer.stopListening();
    }
  };

  return (
    <div>
      <div>Teachable Machine Audio Model</div>
      <button type="button" onClick={handleStart}>Start</button>
      <button type="button" onClick={handleStop}>Stop</button>
      <div id="label-container">
        {results.map((result, index) => (
          <div key={index}>{result.class}: {result.score}</div>
        ))}
      </div>
    </div>
  );
};

export default App;
